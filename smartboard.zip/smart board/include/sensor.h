#ifndef SENSOR_H
#define SENSOR_H

#include <Arduino.h>

class ZMPT101B {
private:
    uint8_t pin;
    float calibrationFactor;
    float offsetVoltage;
    unsigned int numSamples;

    float readRawVoltage();
    bool isValidReading(float voltage);

public:
    ZMPT101B(uint8_t pin, unsigned int samples = 100);
    
    // Initialize the sensor
    void begin();
    
    // Calibration methods
    void calibrate();
    void setCalibrationFactor(float factor);
    
    // Reading methods
    float getVoltage();
    float getVoltageSafe(); // Returns -1 if reading is invalid
    
    // Configuration
    void setSamplesPerRead(unsigned int samples);
    void setOffsetVoltage(float offset);
    
    // Status
    bool isConnected();
};

#endif // SENSOR_H
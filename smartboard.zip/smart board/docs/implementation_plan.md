# ESP32 Smart Control System Implementation Plan

## System Architecture

```mermaid
graph TD
    A[ESP32] --> B[Control System]
    A --> C[Communication System]
    A --> D[Sensor System]
    
    B --> B1[4 GPIO Outputs]
    
    C --> C1[MQTT Client]
    C --> C2[Bluetooth Serial]
    
    D --> D1[ZMPT101B Sensor]
    
    C1 --> E[Online Control/Monitoring]
    C2 --> F[Offline Control/Monitoring]
    
    D1 --> G[Voltage Measurements]
    G --> E
    G --> F
```

## Components Needed
1. Hardware
   - ESP32 Development Board
   - ZMPT101B voltage sensor (0-300V range)
   - 4 output devices (relays/LEDs) for GPIO control

2. Software Libraries
   - PubSubClient (for MQTT)
   - BluetoothSerial (built into ESP32)
   - Required GPIO and ADC libraries

## Implementation Details

1. **GPIO Configuration**
```cpp
// Four output pins will be configured:
#define OUTPUT_1 12  // Example pin numbers, can be changed
#define OUTPUT_2 13
#define OUTPUT_3 14
#define OUTPUT_4 15
```

2. **ZMPT101B Sensor Configuration**
```cpp
// Sensor specifications
#define VOLTAGE_RANGE_MIN 0
#define VOLTAGE_RANGE_MAX 300
#define ADC_PIN 34        // Example ADC pin
#define SAMPLES_PER_READ 100  // For accurate readings
```

3. **Communication Protocol**
```json
// MQTT Topics
{
  "control": "device/outputs/control",
  "status": "device/outputs/status",
  "voltage": "device/sensor/voltage"
}

// Bluetooth Commands
{
  "SET_OUTPUT": "SO,<output_number>,<state>",  // Example: "SO,1,1"
  "GET_VOLTAGE": "GV",
  "GET_STATUS": "GS"
}
```

## State Management
```mermaid
stateDiagram-v2
    [*] --> Initialization
    Initialization --> WiFiConnect
    
    WiFiConnect --> OnlineMode: Connected
    WiFiConnect --> OfflineMode: Failed
    
    OnlineMode --> MQTTConnect
    MQTTConnect --> OnlineMode: Connected
    MQTTConnect --> OfflineMode: Failed
    
    OfflineMode --> BluetoothActive
    
    OnlineMode --> CheckConnection
    CheckConnection --> WiFiConnect: Lost Connection
    
    state OnlineMode {
        [*] --> PublishData
        PublishData --> HandleCommands
        HandleCommands --> PublishData
    }
    
    state OfflineMode {
        [*] --> WaitForBTConnection
        WaitForBTConnection --> HandleBTCommands
        HandleBTCommands --> SendBTData
        SendBTData --> HandleBTCommands
    }
```

## Memory Usage Estimation
- Program Storage: ~256KB
- RAM: ~40KB
- EEPROM: Used for storing configuration

## Error Handling Strategy
1. Sensor Reading Validation
   - Discard readings outside 0-300V range
   - Average multiple readings for accuracy
   - Error indication for invalid readings

2. Communication Failures
   - Automatic mode switching (Online ↔ Offline)
   - Buffering of important data
   - Reconnection attempts with exponential backoff
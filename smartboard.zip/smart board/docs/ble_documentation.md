# SmartBoard BLE Documentation

## Overview
This document contains all the Bluetooth Low Energy (BLE) related information for the SmartBoard project. The SmartBoard uses BLE for wireless communication and control of relays.

## BLE Specifications

### Device Information
- **Device Name**: SmartBoard
- **Device Type**: BLE Peripheral
- **Maximum Range**: 10-30 meters (typical BLE range)
- **Power Requirements**: 3.3V (ESP32)

### Service and Characteristic UUIDs
```cpp
// Service UUID
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"

// Characteristic UUID
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
```

### Characteristic Properties
- READ
- WRITE
- NOTIFY
- INDICATE

## Communication Protocol

### Command Format
All commands are sent as JSON strings with the following format:
```json
{
  "relay0": boolean,
  "relay1": boolean
}
```

### Example Commands
1. Turn on Relay 0, Turn off Relay 1:
```json
{
  "relay0": true,
  "relay1": false
}
```

2. Turn off Relay 0, Turn on Relay 1:
```json
{
  "relay0": false,
  "relay1": true
}
```

3. Turn on both relays:
```json
{
  "relay0": true,
  "relay1": true
}
```

4. Turn off both relays:
```json
{
  "relay0": false,
  "relay1": false
}
```

### Status Updates
The device sends status updates in the same JSON format as notifications. These updates are sent:
1. When a relay state changes
2. Periodically (every 1 second) when connected
3. In response to read requests

## Connection Process
1. Device starts advertising with name "SmartBoard"
2. Client scans and discovers the device
3. Client connects to the device
4. Client discovers services and characteristics
5. Client can read/write to the characteristic
6. Client can enable notifications to receive status updates

## Recommended BLE Scanner Apps

### nRF Connect for Mobile
1. Download from Play Store
2. Open app and click "SCAN"
3. Find "SmartBoard" in the list
4. Click "CONNECT"
5. Navigate to the service and characteristic
6. Use the "WRITE" button to send commands
7. Enable notifications to receive updates

### BLE Scanner
1. Download from Play Store
2. Start scanning
3. Find and connect to "SmartBoard"
4. Access the service and characteristic
5. Send commands in JSON format

### BLE Scanner 4.0
1. Download from Play Store
2. Start scanning
3. Connect to "SmartBoard"
4. Access the service and characteristic
5. Send commands in JSON format

## Troubleshooting

### Common Issues
1. **Device not found in scan**
   - Ensure Bluetooth is enabled on the phone
   - Ensure SmartBoard is powered on
   - Check if SmartBoard is in BLE mode
   - Try moving closer to the device

2. **Connection fails**
   - Try disconnecting and reconnecting
   - Restart the BLE scanner app
   - Restart the SmartBoard
   - Check if another device is already connected

3. **Commands not working**
   - Verify the JSON format is correct
   - Check if notifications are enabled
   - Ensure you're writing to the correct characteristic
   - Verify the device is still connected

### Error Handling
The SmartBoard implements the following error handling:
1. Connection state monitoring
2. Automatic re-advertising when disconnected
3. JSON parsing validation
4. State change confirmation

## Security
- No authentication required for connection
- No encryption by default
- Commands are validated before execution
- State changes are confirmed through notifications

## Power Consumption
- Advertising: ~0.1mA
- Connected: ~1-2mA
- Idle: ~0.01mA
- Active (relay switching): ~5-10mA

## Development Notes
- The BLE implementation uses the ESP32's built-in BLE stack
- Service and characteristic UUIDs are randomly generated
- The device name is hardcoded as "SmartBoard"
- Notifications are sent at 1-second intervals when connected
- All state changes are persisted to non-volatile memory

## Version History
- v1.0: Initial BLE implementation
- v1.1: Added notification support
- v1.2: Improved error handling
- v1.3: Added state persistence
- v1.4: Optimized power consumption

## References
- ESP32 BLE Documentation
- Bluetooth Core Specification v5.0
- nRF Connect Documentation
- BLE Scanner App Documentation 
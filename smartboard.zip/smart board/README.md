# SmartBoard Project Documentation (Hinglish)

## Introduction

SmartBoard ek ESP32-based smart relay control system hai jo multiple modes mein kaam karta hai. Isme 4 relays control karne ki capability hai, aur ye WiFi, MQTT, aur Bluetooth ke through control ho sakta hai. Saath hi isme physical switches aur manual toggle switches bhi add kiye gaye hain.

## Hardware Requirements

- ESP32 Development Board
- 4 Channel Relay Module
- 4 Physical Switches (optional)
- 2 Manual Toggle Switches (optional)
- LED (onboard ya external)
- Mode Selection Button
- Power Supply (5V)

## Pin Connections

### Relay Connections
- Relay 0: GPIO 16
- Relay 1: GPIO 17
- Relay 2: GPIO 18
- Relay 3: GPIO 19

### Physical Switch Connections
- Switch 0: GPIO 21 (with internal pull-up)
- Switch 1: GPIO 22 (with internal pull-up)
- Switch 2: GPIO 23 (with internal pull-up)
- Switch 3: GPIO 25 (with internal pull-up)

### Manual Switch Connections
- Manual Switch 1: GPIO 26 (with internal pull-up)
- Manual Switch 2: GPIO 27 (with internal pull-up)

### Other Connections
- Mode Button: GPIO 4 (with internal pull-up)
- LED: GPIO 2

## Operating Modes

### 1. AP Mode (Access Point Mode)
- Device "SmartBoard_AP" naam se WiFi network create karta hai
- Password: "12345678"
- Web interface http://192.168.4.1 par available hota hai
- Is mode mein aap:
  - Relays ko control kar sakte hain
  - WiFi credentials set kar sakte hain
  - MQTT server settings configure kar sakte hain
  - Manual switches ka configuration kar sakte hain

### 2. WiFi+MQTT Mode
- Saved WiFi credentials se connect karta hai
- MQTT broker se connect hota hai
- Relay states ko MQTT topic "smartboard/relays" par publish karta hai
- MQTT commands se relays ko control kar sakte hain
- Har 1 second mein status update bhejta hai

### 3. Bluetooth Mode
- "SmartBoard" naam se Bluetooth device dikhta hai
- JSON format mein commands accept karta hai
- Real-time status updates bhejta hai

## Manual Switch Configuration

1. AP mode mein web interface par "Manual Switches" page par jaayein
2. Dropdown menus se select karein ki Manual Switch 1 aur 2 kaunse relay control karenge
3. "Save Configuration" button par click karein
4. Configuration save ho jayega aur device restart hoga

## MQTT Commands

MQTT topic "smartboard/relays" par JSON format mein commands bhej sakte hain:

```json
{"relay0":true}  // Relay 0 ko ON karta hai
{"relay1":false} // Relay 1 ko OFF karta hai
{"relay2":true}  // Relay 2 ko ON karta hai
{"relay3":false} // Relay 3 ko OFF karta hai
```

Multiple relays ko ek saath control karne ke liye:
```json
{"relay0":true,"relay1":false,"relay2":true,"relay3":false}
```

## Bluetooth Commands

Bluetooth ke through bhi same JSON format mein commands bhej sakte hain:

```json
{"relay0":true}  // Relay 0 ko ON karta hai
{"relay1":false} // Relay 1 ko OFF karta hai
```

## Status Updates

Device regularly status updates bhejta hai:

1. **MQTT Status**: Har 1 second mein
2. **Bluetooth Status**: Har 1 second mein
3. **Web Interface**: Real-time updates
4. **Serial Monitor**: Har state change par

Status format (JSON):
```json
{
  "relay0": true,
  "relay1": false,
  "relay2": true,
  "relay3": false
}
```

## Mode Switching

1. Mode button ko press karke mode switch kar sakte hain
2. LED blinking pattern se current mode pata chal jata hai:
   - AP Mode: Fast blinking (50ms interval)
   - WiFi+MQTT Mode: Slow blinking (250ms interval)

## Error Handling

1. **WiFi Connection**:
   - 10 seconds timeout
   - Connection fail hone par AP mode mein switch ho jata hai
   - Reconnection attempts automatically

2. **MQTT Connection**:
   - 5 seconds timeout
   - Connection fail hone par WiFi mode mein reh jata hai
   - Har 5 seconds mein reconnection attempt karta hai

3. **Bluetooth**:
   - Initialization fail hone par system continue karta hai
   - Connection lost hone par automatically reconnect karta hai

## Physical Switches

1. Har physical switch corresponding relay ko toggle karta hai
2. Switch press karne par relay state change hota hai
3. State change MQTT aur Bluetooth ke through broadcast hota hai
4. Debounce delay (250ms) false triggers ko prevent karta hai

## Manual Switches

1. Manual Switch 1 aur 2 ko configure kar sakte hain ki wo kaunse relay control karenge
2. Configuration web interface se change kar sakte hain
3. Configuration device restart ke baad bhi save rahta hai
4. Switches press karne par corresponding relay toggle hota hai

## Web Interface Features

1. **Dashboard**:
   - All relays ka status dikhata hai
   - Toggle buttons se relays ko control kar sakte hain
   - Real-time updates
   - Connection status display

2. **Settings**:
   - WiFi credentials set karne ka option
   - MQTT server settings configure karne ka option
   - Optional MQTT username/password

3. **Manual Switches**:
   - Manual switches ka configuration
   - Dropdown menus se relay selection
   - Save configuration option

## Troubleshooting

1. **WiFi Connect Nahi Ho Raha**:
   - AP mode mein switch karein
   - Web interface se WiFi credentials check karein
   - Router ka signal strength check karein

2. **MQTT Connect Nahi Ho Raha**:
   - MQTT server address aur port check karein
   - Username/password correct hai ya nahi check karein
   - Internet connection check karein

3. **Bluetooth Connect Nahi Ho Raha**:
   - Device ka Bluetooth ON hai ya nahi check karein
   - Device "SmartBoard" naam se dikh raha hai ya nahi check karein
   - Device ko restart karein

4. **Relays Kaam Nahi Kar Rahe**:
   - Power supply check karein
   - Relay module connections check karein
   - GPIO pins check karein

## Future Improvements

1. OTA (Over-the-Air) updates add kar sakte hain
2. More relays add kar sakte hain
3. Temperature sensors add kar sakte hain
4. Mobile app develop kar sakte hain
5. Voice control add kar sakte hain
6. Scheduling feature add kar sakte hain
7. Power consumption monitoring add kar sakte hain
8. Multiple MQTT topics support add kar sakte hain
9. WebSocket support add kar sakte hain
10. SSL/TLS encryption add kar sakte hain

## Conclusion

SmartBoard ek versatile smart home control system hai jo multiple interfaces (Web, MQTT, Bluetooth) ke through control ho sakta hai. Isme physical switches aur manual toggle switches ka support hai, aur ye reliable error handling ke saath kaam karta hai. Future mein isme aur features add kiye ja sakte hain.
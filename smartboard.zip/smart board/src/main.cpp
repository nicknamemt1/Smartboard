#include "main.h"

// Pin Definitions
const int RELAY_PINS[] = {16, 17};  // Relay control pins
int MODE_BUTTON_PIN = 4;            // Mode selection button
int LED_PIN = 2;                    // Onboard LED
const int MANUAL_SWITCH1_PIN = 26;  // Manual switch 1
const int MANUAL_SWITCH2_PIN = 27;  // Manual switch 2

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <PubSubClient.h>
#include <Preferences.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <ArduinoJson.h>

// Forward declarations
void savePreferences();
void notifyBTStatus();
void setupPins();
void loadPreferences();
void handleModeButton();
void updateLED();
void setupAPMode();
void setupWiFiMQTTMode();
void setupBluetoothMode();
void handleWebServer();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void reconnectMQTT();
void publishRelayStates();
void handleManualSwitches();
void printModeStatus();
bool connectToWiFi();
bool connectToMQTT();

// Constants
const int NUM_RELAYS = 2;
const char* DEFAULT_MQTT_SERVER = "broker.emqx.io";
const int DEFAULT_MQTT_PORT = 1883;
const char* MQTT_TOPIC = "smartboard/relays";
const unsigned long MQTT_PUBLISH_INTERVAL = 1000;
const unsigned long DEBOUNCE_DELAY = 250;
const unsigned long MODE_CHANGE_DELAY = 1000;
const unsigned long WIFI_TIMEOUT = 10000;
const unsigned long MQTT_TIMEOUT = 5000;
const unsigned long MQTT_RECONNECT_DELAY = 5000;
const unsigned long MQTT_MAX_RETRIES = 3;

// BLE UUIDs
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

// Preferences keys
const char* RELAY_ACTIVE_STATE_KEY = "relay_active_state";

// Global Variables
WebServer webServer(80);
WiFiClient wifiClient;
PubSubClient mqttClient(wifiClient);
Preferences preferences;

// BLE Variables
BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

// Mode enumeration
enum OperationMode {
  AP_MODE,
  WIFI_MQTT_MODE
};

// Global state
OperationMode currentMode = AP_MODE;
bool relayStates[NUM_RELAYS] = {false};
bool relayActiveStates[NUM_RELAYS] = {HIGH, HIGH};
unsigned long lastMqttPublish = 0;
unsigned long lastModeButtonPress = 0;
unsigned long lastModeChange = 0;
bool lastModeButtonState = HIGH;
bool modeButtonPressed = false;
bool wifiConnected = false;
bool mqttConnected = false;
bool isConnecting = false;
bool btInitialized = false;

// Manual switch configuration
int manualSwitch1Relay = 0;
int manualSwitch2Relay = 1;
bool lastManualSwitch1State = HIGH;
bool lastManualSwitch2State = HIGH;
unsigned long lastManualSwitch1Debounce = 0;
unsigned long lastManualSwitch2Debounce = 0;
bool manualSwitch1ActiveState = LOW;
bool manualSwitch2ActiveState = LOW;

// BLE Server Callbacks
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("BLE Device Connected");
      // Send initial status when connected
      notifyBTStatus();
    };

    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("BLE Device Disconnected");
      // Restart advertising
      pServer->startAdvertising();
    }
};

// BLE Characteristic Callbacks
class MyCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
      std::string value = pCharacteristic->getValue();
      
      if (value.length() > 0) {
        String message = "";
        for (int i = 0; i < value.length(); i++) {
          message += (char)value[i];
        }
        
        Serial.println("Received BLE command: " + message);
        
        // Parse simple command format: R0:1 or R1:0
        if (message.startsWith("R0:")) {
          bool newState = message.substring(3) == "1";
          Serial.println("Setting Relay 0 to: " + String(newState ? "ON" : "OFF"));
          relayStates[0] = newState;
          digitalWrite(RELAY_PINS[0], relayStates[0] ? relayActiveStates[0] : !relayActiveStates[0]);
          savePreferences();
          notifyBTStatus();
        }
        else if (message.startsWith("R1:")) {
          bool newState = message.substring(3) == "1";
          Serial.println("Setting Relay 1 to: " + String(newState ? "ON" : "OFF"));
          relayStates[1] = newState;
          digitalWrite(RELAY_PINS[1], relayStates[1] ? relayActiveStates[1] : !relayActiveStates[1]);
          savePreferences();
          notifyBTStatus();
        }
        else {
          Serial.println("Invalid command format. Use R0:1 or R1:0");
        }
      }
    }
};

void setup() {
  // Initialize serial with a delay to ensure stability
  delay(1000);
  Serial.begin(115200);
  while (!Serial) {
    delay(10);
  }
  
  Serial.println("\n\n=== SmartBoard System Starting ===");
  Serial.println("Initializing system...");
  
  setupPins();
  Serial.println("Pins initialized");
  
  // Initialize preferences
  preferences.begin("smartboard", false);
  Serial.println("Preferences initialized");
  
  // Initialize Bluetooth with error handling
  try {
    Serial.println("Initializing Bluetooth...");
    setupBluetoothMode();
    btInitialized = true;
    Serial.println("Bluetooth initialized successfully");
  } catch (...) {
    Serial.println("Bluetooth initialization failed - continuing without Bluetooth");
    btInitialized = false;
  }
  
  // Check if this is first boot
  if (!preferences.isKey("initialized")) {
    Serial.println("First boot detected - Setting up AP mode");
    currentMode = AP_MODE;
    preferences.putUChar("mode", AP_MODE);
    preferences.putBool("initialized", true);
  } else {
    loadPreferences();
  }
  
  // Load manual switch configuration
  manualSwitch1Relay = preferences.getInt("manual_switch1", 0);
  manualSwitch2Relay = preferences.getInt("manual_switch2", 1);
  Serial.printf("Manual Switch 1 configured for relay %d\n", manualSwitch1Relay);
  Serial.printf("Manual Switch 2 configured for relay %d\n", manualSwitch2Relay);
  
  // Load relay active states
  for(int i = 0; i < NUM_RELAYS; i++) {
    relayActiveStates[i] = preferences.getBool((RELAY_ACTIVE_STATE_KEY + String(i)).c_str(), HIGH);
  }
  
  printModeStatus();
  
  // Set initial mode
  switch (currentMode) {
    case AP_MODE:
      setupAPMode();
      break;
    case WIFI_MQTT_MODE:
      setupWiFiMQTTMode();
      break;
  }
  Serial.println("=== System Initialization Complete ===\n");
}

void printModeStatus() {
  Serial.print("Current mode: ");
  switch (currentMode) {
    case AP_MODE: 
      Serial.println("AP Mode");
      Serial.println("Connect to 'SmartBoard_AP' with password '12345678'");
      break;
    case WIFI_MQTT_MODE: 
      Serial.println("WiFi+MQTT Mode");
      Serial.print("Connected to: ");
      Serial.println(WiFi.SSID());
      break;
  }
}

void setupPins() {
  // Setup relay pins
  for(int i = 0; i < NUM_RELAYS; i++) {
    pinMode(RELAY_PINS[i], OUTPUT);
    digitalWrite(RELAY_PINS[i], LOW);
  }
  
  // Setup manual switch pins with internal pullup
  pinMode(MANUAL_SWITCH1_PIN, INPUT_PULLUP);
  pinMode(MANUAL_SWITCH2_PIN, INPUT_PULLUP);
  
  // Setup mode button and LED
  pinMode(MODE_BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
}

void loadPreferences() {
  Serial.println("Loading preferences...");
  
  // Load mode
  currentMode = (OperationMode)preferences.getUChar("mode", AP_MODE);
  Serial.print("Loaded mode from preferences: ");
  switch (currentMode) {
    case AP_MODE: Serial.println("AP Mode"); break;
    case WIFI_MQTT_MODE: Serial.println("WiFi+MQTT Mode"); break;
  }
  
  // Load relay states
  for (int i = 0; i < NUM_RELAYS; i++) {
    relayStates[i] = preferences.getBool(("relay" + String(i)).c_str(), false);
    digitalWrite(RELAY_PINS[i], relayStates[i] ? relayActiveStates[i] : !relayActiveStates[i]);
    Serial.printf("Relay %d state loaded: %s\n", i, relayStates[i] ? "ON" : "OFF");
  }
  
  // Load relay active states
  for(int i = 0; i < NUM_RELAYS; i++) {
    relayActiveStates[i] = preferences.getBool((RELAY_ACTIVE_STATE_KEY + String(i)).c_str(), HIGH);
  }
}

void savePreferences() {
  Serial.println("Saving preferences...");
  preferences.putUChar("mode", currentMode);
  Serial.print("Saved mode to preferences: ");
  switch (currentMode) {
    case AP_MODE: Serial.println("AP Mode"); break;
    case WIFI_MQTT_MODE: Serial.println("WiFi+MQTT Mode"); break;
  }
  
  for (int i = 0; i < NUM_RELAYS; i++) {
    preferences.putBool(("relay" + String(i)).c_str(), relayStates[i]);
    preferences.putBool((RELAY_ACTIVE_STATE_KEY + String(i)).c_str(), relayActiveStates[i]);
    Serial.printf("Relay %d state saved: %s\n", i, relayStates[i] ? "ON" : "OFF");
  }
  
  preferences.putInt("manual_switch1", manualSwitch1Relay);
  preferences.putInt("manual_switch2", manualSwitch2Relay);
  preferences.putBool("manual_switch1_active_state", manualSwitch1ActiveState);
  preferences.putBool("manual_switch2_active_state", manualSwitch2ActiveState);
  preferences.end();
  preferences.begin("smartboard", false);
}

void handleModeButton() {
  bool currentButtonState = digitalRead(MODE_BUTTON_PIN);
  unsigned long currentTime = millis();
  
  if (currentButtonState != lastModeButtonState) {
    if (currentTime - lastModeButtonPress > DEBOUNCE_DELAY) {
      if (currentButtonState == LOW && !modeButtonPressed) {
        modeButtonPressed = true;
        lastModeButtonPress = currentTime;
        
        if (isConnecting) {
          Serial.println("Aborting ongoing connection process");
          if (WiFi.status() == WL_CONNECTED) {
            WiFi.disconnect();
          }
          if (mqttClient.connected()) {
            mqttClient.disconnect();
          }
          isConnecting = false;
          delay(100);
        }
      }
      else if (currentButtonState == HIGH && modeButtonPressed) {
        modeButtonPressed = false;
        if (currentTime - lastModeChange > MODE_CHANGE_DELAY) {
          switch (currentMode) {
            case WIFI_MQTT_MODE:
              if (mqttClient.connected()) {
                mqttClient.disconnect();
              }
              if (WiFi.status() == WL_CONNECTED) {
                WiFi.disconnect();
              }
              break;
            case AP_MODE:
              webServer.close();
              break;
          }
          
          currentMode = (OperationMode)((currentMode + 1) % 2);
          lastModeChange = currentTime;
          
          Serial.println("\n=== Mode Change ===");
          Serial.print("Switching to: ");
          Serial.println(currentMode == AP_MODE ? "AP Mode" : "WiFi+MQTT Mode");
          
          savePreferences();
          
          switch (currentMode) {
            case AP_MODE:
              setupAPMode();
              break;
            case WIFI_MQTT_MODE:
              setupWiFiMQTTMode();
              break;
          }
        }
      }
    }
  }
  lastModeButtonState = currentButtonState;
}

void updateLED() {
  static unsigned long lastBlink = 0;
  int blinkInterval;
  
  switch (currentMode) {
    case AP_MODE:
      blinkInterval = 50;  // Fast blink in AP mode
      break;
    case WIFI_MQTT_MODE:
      if (!mqttConnected) {
        blinkInterval = 250;  // Medium blink while connecting
      } else {
        digitalWrite(LED_PIN, HIGH);  // Stable ON when connected
        return;
      }
      break;
  }
  
  if (millis() - lastBlink >= blinkInterval) {
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));
    lastBlink = millis();
  }
}

void setupAPMode() {
  Serial.println("\n=== AP Mode Configuration ===");
  
  // Stop any existing WiFi connections
  WiFi.disconnect();
  WiFi.mode(WIFI_AP);
  
  // Configure AP
  IPAddress localIP(192, 168, 4, 1);
  IPAddress gateway(192, 168, 4, 1);
  IPAddress subnet(255, 255, 255, 0);
  
  WiFi.softAPConfig(localIP, gateway, subnet);
  WiFi.softAP("SmartBoard_AP", "12345678");
  
  Serial.println("AP Mode Started");
  Serial.print("IP Address: "); Serial.println(WiFi.softAPIP());
  Serial.print("SSID: SmartBoard_AP");
  Serial.print("Password: 12345678");
  
  // Setup web server directly
  // Dashboard page
  webServer.on("/", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>SmartBoard Status</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".relay-grid {"
                 "  display: grid;"
                 "  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));"
                 "  gap: 15px;"
                 "  margin-bottom: 20px;"
                 "}"
                 ".relay-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  text-align: center;"
                 "}"
                 ".toggle-btn {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  border: none;"
                 "  padding: 10px 20px;"
                 "  border-radius: 4px;"
                 "  cursor: pointer;"
                 "  font-size: 16px;"
                 "}"
                 ".toggle-btn.on {"
                 "  background: var(--success-color);"
                 "}"
                 ".toggle-btn.off {"
                 "  background: var(--danger-color);"
                 "}"
                 ".status-indicator {"
                 "  width: 20px;"
                 "  height: 20px;"
                 "  border-radius: 50%;"
                 "  display: inline-block;"
                 "  margin-right: 10px;"
                 "}"
                 ".status-indicator.on {"
                 "  background: var(--success-color);"
                 "  box-shadow: 0 0 10px var(--success-color);"
                 "}"
                 ".status-indicator.off {"
                 "  background: var(--danger-color);"
                 "  box-shadow: 0 0 10px var(--danger-color);"
                 "}"
                 "</style>"
                 "<script>"
                 "function updateStatus() {"
                 "  fetch('/status')"
                 "    .then(response => response.json())"
                 "    .then(data => {"
                 "      for(let i = 0; i < 2; i++) {"
                 "        const state = data['relay' + i];"
                 "        document.getElementById('indicator' + i).className = 'status-indicator ' + (state ? 'on' : 'off');"
                 "        const btn = document.getElementById('btn' + i);"
                 "        btn.className = 'toggle-btn ' + (state ? 'on' : 'off');"
                 "        btn.textContent = state ? 'ON' : 'OFF';"
                 "      }"
                 "    });"
                 "}"
                 ""
                 "function toggleRelay(relayNum) {"
                 "  fetch('/toggle/' + relayNum, {"
                 "    method: 'POST'"
                 "  })"
                 "  .then(response => response.json())"
                 "  .then(data => {"
                 "    const state = data.state;"
                 "    document.getElementById('indicator' + relayNum).className = 'status-indicator ' + (state ? 'on' : 'off');"
                 "    const btn = document.getElementById('btn' + relayNum);"
                 "    btn.className = 'toggle-btn ' + (state ? 'on' : 'off');"
                 "    btn.textContent = state ? 'ON' : 'OFF';"
                 "  });"
                 "}"
                 ""
                 "// Update status every second"
                 "setInterval(updateStatus, 1000);"
                 ""
                 "// Initial status update"
                 "updateStatus();"
                 "</script>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>SmartBoard Control</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='relay-grid'>";
    
    for(int i = 0; i < NUM_RELAYS; i++) {
      html += "<div class='relay-card'>"
              "<h3>Relay " + String(i) + "</h3>"
              "<div style='margin: 20px 0;'>"
              "<span id='indicator" + String(i) + "' class='status-indicator " + String(relayStates[i] ? "on" : "off") + "'></span>"
              "<button id='btn" + String(i) + "' class='toggle-btn " + String(relayStates[i] ? "on" : "off") + "' "
              "onclick='toggleRelay(" + String(i) + ")'>"
              + String(relayStates[i] ? "ON" : "OFF") + "</button>"
              "</div>"
              "</div>";
    }
    
    html += "</div>"
            "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  // Status endpoint
  webServer.on("/status", HTTP_GET, []() {
    String json = "{";
    for(int i = 0; i < NUM_RELAYS; i++) {
      json += "\"relay" + String(i) + "\":" + String(relayStates[i] ? "true" : "false");
      if(i < NUM_RELAYS - 1) json += ",";
    }
    json += "}";
    webServer.send(200, "application/json", json);
  });

  // Toggle relay endpoints
  webServer.on("/toggle/0", HTTP_POST, []() {
    relayStates[0] = !relayStates[0];
    digitalWrite(RELAY_PINS[0], relayStates[0] ? relayActiveStates[0] : !relayActiveStates[0]);
    savePreferences();
    String json = "{\"state\":" + String(relayStates[0] ? "true" : "false") + "}";
    webServer.send(200, "application/json", json);
  });

  webServer.on("/toggle/1", HTTP_POST, []() {
    relayStates[1] = !relayStates[1];
    digitalWrite(RELAY_PINS[1], relayStates[1] ? relayActiveStates[1] : !relayActiveStates[1]);
    savePreferences();
    String json = "{\"state\":" + String(relayStates[1] ? "true" : "false") + "}";
    webServer.send(200, "application/json", json);
  });

  // Manual switch configuration page
  webServer.on("/manual-switches", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>Manual Switch Configuration</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "}"
                 ".form-card:hover {"
                 "  transform: translateY(-5px);"
                 "  box-shadow: 0 5px 15px rgba(0,0,0,0.2);"
                 "}"
                 "@keyframes fadeIn {"
                 "  from { opacity: 0; transform: translateY(20px); }"
                 "  to { opacity: 1; transform: translateY(0); }"
                 "}"
                 ".form-group {"
                 "  margin-bottom: 20px;"
                 "  animation: slideIn 0.5s ease-in-out;"
                 "}"
                 "@keyframes slideIn {"
                 "  from { opacity: 0; transform: translateX(-20px); }"
                 "  to { opacity: 1; transform: translateX(0); }"
                 "}"
                 ".form-group label {"
                 "  display: block;"
                 "  margin-bottom: 5px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-group select {"
                 "  width: 100%;"
                 "  padding: 8px;"
                 "  border: 1px solid #ddd;"
                 "  border-radius: 4px;"
                 "  transition: all 0.3s ease;"
                 "}"
                 ".form-group select:focus {"
                 "  border-color: var(--primary-color);"
                 "  box-shadow: 0 0 5px rgba(33, 150, 243, 0.3);"
                 "  transform: translateY(-2px);"
                 "}"
                 ".active-state-group {"
                 "  background: rgba(33, 150, 243, 0.1);"
                 "  padding: 15px;"
                 "  border-radius: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".btn {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  border: none;"
                 "  padding: 10px 20px;"
                 "  border-radius: 4px;"
                 "  cursor: pointer;"
                 "  font-size: 16px;"
                 "}"
                 ".btn:hover {"
                 "  transform: scale(1.05);"
                 "  box-shadow: 0 4px 8px rgba(0,0,0,0.2);"
                 "}"
                 "</style>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>Manual Switch Configuration</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='form-card'>"
                 "<form method='POST' action='/save-manual-switches'>"
                 "<div class='form-group'>"
                 "<label>Manual Switch 1 Controls</label>"
                 "<select name='manual_switch1'>";
    
    for (int i = 0; i < NUM_RELAYS; i++) {
      html += "<option value='" + String(i) + "'" + 
              (i == manualSwitch1Relay ? " selected" : "") + 
              ">Relay " + String(i) + "</option>";
    }
    
    html += "</select>"
            "</div>"
            "<div class='active-state-group'>"
            "<label>Manual Switch 1 Active State</label>"
            "<select name='manual_switch1_active_state'>"
            "<option value='0'" + String(manualSwitch1ActiveState == LOW ? " selected" : "") + ">LOW</option>"
            "<option value='1'" + String(manualSwitch1ActiveState == HIGH ? " selected" : "") + ">HIGH</option>"
            "</select>"
            "<p style='font-size: 0.9em; color: #666; margin-top: 5px;'>"
            "Select whether the switch activates on LOW or HIGH signal</p>"
            "</div>"
            "<div class='form-group'>"
            "<label>Manual Switch 2 Controls</label>"
            "<select name='manual_switch2'>";
    
    for (int i = 0; i < NUM_RELAYS; i++) {
      html += "<option value='" + String(i) + "'" + 
              (i == manualSwitch2Relay ? " selected" : "") + 
              ">Relay " + String(i) + "</option>";
    }
    
    html += "</select>"
            "</div>"
            "<div class='active-state-group'>"
            "<label>Manual Switch 2 Active State</label>"
            "<select name='manual_switch2_active_state'>"
            "<option value='0'" + String(manualSwitch2ActiveState == LOW ? " selected" : "") + ">LOW</option>"
            "<option value='1'" + String(manualSwitch2ActiveState == HIGH ? " selected" : "") + ">HIGH</option>"
            "</select>"
            "<p style='font-size: 0.9em; color: #666; margin-top: 5px;'>"
            "Select whether the switch activates on LOW or HIGH signal</p>"
            "</div>"
            "<button type='submit' class='btn'>Save Configuration</button>"
            "</form>"
            "</div>"
            "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  // Save manual switches endpoint
  webServer.on("/save-manual-switches", HTTP_POST, []() {
    if (webServer.hasArg("manual_switch1") && webServer.hasArg("manual_switch2")) {
      manualSwitch1Relay = webServer.arg("manual_switch1").toInt();
      manualSwitch2Relay = webServer.arg("manual_switch2").toInt();
      
      // Save active states
      manualSwitch1ActiveState = webServer.arg("manual_switch1_active_state").toInt() == 1 ? HIGH : LOW;
      manualSwitch2ActiveState = webServer.arg("manual_switch2_active_state").toInt() == 1 ? HIGH : LOW;
      
      // Save to preferences
      preferences.putInt("manual_switch1", manualSwitch1Relay);
      preferences.putInt("manual_switch2", manualSwitch2Relay);
      preferences.putBool("manual_switch1_active_state", manualSwitch1ActiveState);
      preferences.putBool("manual_switch2_active_state", manualSwitch2ActiveState);
      
      String response = "<html><head><title>Configuration Saved</title>"
                       "<style>body { font-family: Arial; margin: 20px; text-align: center; }"
                       "h1 { color: #4CAF50; }</style></head><body>"
                       "<h1>Manual Switch Configuration Saved!</h1>"
                       "<p>Manual Switch 1 will control Relay " + String(manualSwitch1Relay) + 
                       " (Active on " + String(manualSwitch1ActiveState == HIGH ? "HIGH" : "LOW") + ")</p>"
                       "<p>Manual Switch 2 will control Relay " + String(manualSwitch2Relay) + 
                       " (Active on " + String(manualSwitch2ActiveState == HIGH ? "HIGH" : "LOW") + ")</p>"
                       "<p><a href='/manual-switches' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Configuration</a></p>"
                       "</body></html>";
      webServer.send(200, "text/html", response);
    }
  });

  webServer.on("/pin-connections", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>Pin Connections</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".pin-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "}"
                 ".pin-card:hover {"
                 "  transform: translateY(-5px);"
                 "  box-shadow: 0 5px 15px rgba(0,0,0,0.2);"
                 "}"
                 "@keyframes fadeIn {"
                 "  from { opacity: 0; transform: translateY(20px); }"
                 "  to { opacity: 1; transform: translateY(0); }"
                 "}"
                 ".pin-row {"
                 "  display: flex;"
                 "  justify-content: space-between;"
                 "  padding: 10px 0;"
                 "  border-bottom: 1px solid #eee;"
                 "}"
                 ".pin-row:last-child {"
                 "  border-bottom: none;"
                 "}"
                 "</style>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>Pin Connections</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='pin-card'>"
                 "<h2>Relay Connections</h2>"
                 "<div class='pin-row'>"
                 "<span>Relay 1</span>"
                 "<span>GPIO " + String(RELAY_PINS[0]) + "</span>"
                 "</div>"
                 "<div class='pin-row'>"
                 "<span>Relay 2</span>"
                 "<span>GPIO " + String(RELAY_PINS[1]) + "</span>"
                 "</div>"
                 "</div>"
                 "<div class='pin-card'>"
                 "<h2>Manual Switch Connections</h2>"
                 "<div class='pin-row'>"
                 "<span>Manual Switch 1</span>"
                 "<span>GPIO " + String(MANUAL_SWITCH1_PIN) + "</span>"
                 "</div>"
                 "<div class='pin-row'>"
                 "<span>Manual Switch 2</span>"
                 "<span>GPIO " + String(MANUAL_SWITCH2_PIN) + "</span>"
                 "</div>"
                 "</div>"
                 "<div class='pin-card'>"
                 "<h2>System Connections</h2>"
                 "<div class='pin-row'>"
                 "<span>Mode Change Button</span>"
                 "<span>GPIO " + String(MODE_BUTTON_PIN) + "</span>"
                 "</div>"
                 "<div class='pin-row'>"
                 "<span>Status LED</span>"
                 "<span>GPIO " + String(LED_PIN) + "</span>"
                 "</div>"
                 "</div>"
                 "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  webServer.on("/relay-config", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>Relay Configuration</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "}"
                 ".form-group {"
                 "  margin-bottom: 20px;"
                 "}"
                 ".form-group label {"
                 "  display: block;"
                 "  margin-bottom: 5px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-group select {"
                 "  width: 100%;"
                 "  padding: 8px;"
                 "  border: 1px solid #ddd;"
                 "  border-radius: 4px;"
                 "}"
                 ".btn {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  border: none;"
                 "  padding: 10px 20px;"
                 "  border-radius: 4px;"
                 "  cursor: pointer;"
                 "  font-size: 16px;"
                 "}"
                 "</style>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>Relay Configuration</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='form-card'>"
                 "<form method='POST' action='/save-relay-config'>"
                 "<div class='form-group'>"
                 "<label>Relay 1 Active State</label>"
                 "<select name='relay1_active_state'>"
                 "<option value='0'" + String(relayActiveStates[0] == LOW ? " selected" : "") + ">LOW</option>"
                 "<option value='1'" + String(relayActiveStates[0] == HIGH ? " selected" : "") + ">HIGH</option>"
                 "</select>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>Relay 2 Active State</label>"
                 "<select name='relay2_active_state'>"
                 "<option value='0'" + String(relayActiveStates[1] == LOW ? " selected" : "") + ">LOW</option>"
                 "<option value='1'" + String(relayActiveStates[1] == HIGH ? " selected" : "") + ">HIGH</option>"
                 "</select>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>Mode Change Button Pin</label>"
                 "<select name='mode_button_pin'>"
                 "<option value='4'" + String(MODE_BUTTON_PIN == 4 ? " selected" : "") + ">GPIO 4</option>"
                 "<option value='5'" + String(MODE_BUTTON_PIN == 5 ? " selected" : "") + ">GPIO 5</option>"
                 "<option value='12'" + String(MODE_BUTTON_PIN == 12 ? " selected" : "") + ">GPIO 12</option>"
                 "<option value='13'" + String(MODE_BUTTON_PIN == 13 ? " selected" : "") + ">GPIO 13</option>"
                 "<option value='14'" + String(MODE_BUTTON_PIN == 14 ? " selected" : "") + ">GPIO 14</option>"
                 "<option value='15'" + String(MODE_BUTTON_PIN == 15 ? " selected" : "") + ">GPIO 15</option>"
                 "<option value='16'" + String(MODE_BUTTON_PIN == 16 ? " selected" : "") + ">GPIO 16</option>"
                 "<option value='17'" + String(MODE_BUTTON_PIN == 17 ? " selected" : "") + ">GPIO 17</option>"
                 "<option value='18'" + String(MODE_BUTTON_PIN == 18 ? " selected" : "") + ">GPIO 18</option>"
                 "<option value='19'" + String(MODE_BUTTON_PIN == 19 ? " selected" : "") + ">GPIO 19</option>"
                 "<option value='21'" + String(MODE_BUTTON_PIN == 21 ? " selected" : "") + ">GPIO 21</option>"
                 "<option value='22'" + String(MODE_BUTTON_PIN == 22 ? " selected" : "") + ">GPIO 22</option>"
                 "<option value='23'" + String(MODE_BUTTON_PIN == 23 ? " selected" : "") + ">GPIO 23</option>"
                 "<option value='25'" + String(MODE_BUTTON_PIN == 25 ? " selected" : "") + ">GPIO 25</option>"
                 "<option value='26'" + String(MODE_BUTTON_PIN == 26 ? " selected" : "") + ">GPIO 26</option>"
                 "<option value='27'" + String(MODE_BUTTON_PIN == 27 ? " selected" : "") + ">GPIO 27</option>"
                 "<option value='32'" + String(MODE_BUTTON_PIN == 32 ? " selected" : "") + ">GPIO 32</option>"
                 "<option value='33'" + String(MODE_BUTTON_PIN == 33 ? " selected" : "") + ">GPIO 33</option>"
                 "<option value='34'" + String(MODE_BUTTON_PIN == 34 ? " selected" : "") + ">GPIO 34</option>"
                 "<option value='35'" + String(MODE_BUTTON_PIN == 35 ? " selected" : "") + ">GPIO 35</option>"
                 "<option value='36'" + String(MODE_BUTTON_PIN == 36 ? " selected" : "") + ">GPIO 36</option>"
                 "<option value='39'" + String(MODE_BUTTON_PIN == 39 ? " selected" : "") + ">GPIO 39</option>"
                 "</select>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>Status LED Pin</label>"
                 "<select name='led_pin'>"
                 "<option value='2'" + String(LED_PIN == 2 ? " selected" : "") + ">GPIO 2</option>"
                 "<option value='4'" + String(LED_PIN == 4 ? " selected" : "") + ">GPIO 4</option>"
                 "<option value='5'" + String(LED_PIN == 5 ? " selected" : "") + ">GPIO 5</option>"
                 "<option value='12'" + String(LED_PIN == 12 ? " selected" : "") + ">GPIO 12</option>"
                 "<option value='13'" + String(LED_PIN == 13 ? " selected" : "") + ">GPIO 13</option>"
                 "<option value='14'" + String(LED_PIN == 14 ? " selected" : "") + ">GPIO 14</option>"
                 "<option value='15'" + String(LED_PIN == 15 ? " selected" : "") + ">GPIO 15</option>"
                 "<option value='16'" + String(LED_PIN == 16 ? " selected" : "") + ">GPIO 16</option>"
                 "<option value='17'" + String(LED_PIN == 17 ? " selected" : "") + ">GPIO 17</option>"
                 "<option value='18'" + String(LED_PIN == 18 ? " selected" : "") + ">GPIO 18</option>"
                 "<option value='19'" + String(LED_PIN == 19 ? " selected" : "") + ">GPIO 19</option>"
                 "<option value='21'" + String(LED_PIN == 21 ? " selected" : "") + ">GPIO 21</option>"
                 "<option value='22'" + String(LED_PIN == 22 ? " selected" : "") + ">GPIO 22</option>"
                 "<option value='23'" + String(LED_PIN == 23 ? " selected" : "") + ">GPIO 23</option>"
                 "<option value='25'" + String(LED_PIN == 25 ? " selected" : "") + ">GPIO 25</option>"
                 "<option value='26'" + String(LED_PIN == 26 ? " selected" : "") + ">GPIO 26</option>"
                 "<option value='27'" + String(LED_PIN == 27 ? " selected" : "") + ">GPIO 27</option>"
                 "<option value='32'" + String(LED_PIN == 32 ? " selected" : "") + ">GPIO 32</option>"
                 "<option value='33'" + String(LED_PIN == 33 ? " selected" : "") + ">GPIO 33</option>"
                 "</select>"
                 "</div>"
                 "<button type='submit' class='btn'>Save Configuration</button>"
                 "</form>"
                 "</div>"
                 "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  // Save relay configuration endpoint
  webServer.on("/save-relay-config", HTTP_POST, []() {
    if (webServer.hasArg("relay1_active_state") && webServer.hasArg("relay2_active_state") &&
        webServer.hasArg("mode_button_pin") && webServer.hasArg("led_pin")) {
      
      // Save relay active states
      relayActiveStates[0] = webServer.arg("relay1_active_state").toInt() == 1 ? HIGH : LOW;
      relayActiveStates[1] = webServer.arg("relay2_active_state").toInt() == 1 ? HIGH : LOW;
      
      // Save mode button and LED pins
      int newModeButtonPin = webServer.arg("mode_button_pin").toInt();
      int newLedPin = webServer.arg("led_pin").toInt();
      
      // Update pins if they've changed
      if (newModeButtonPin != MODE_BUTTON_PIN) {
        pinMode(MODE_BUTTON_PIN, INPUT);  // Reset old pin
        MODE_BUTTON_PIN = newModeButtonPin;
        pinMode(MODE_BUTTON_PIN, INPUT_PULLUP);
      }
      
      if (newLedPin != LED_PIN) {
        pinMode(LED_PIN, INPUT);  // Reset old pin
        LED_PIN = newLedPin;
        pinMode(LED_PIN, OUTPUT);
      }
      
      // Save to preferences
      preferences.putBool((RELAY_ACTIVE_STATE_KEY + String(0)).c_str(), relayActiveStates[0]);
      preferences.putBool((RELAY_ACTIVE_STATE_KEY + String(1)).c_str(), relayActiveStates[1]);
      preferences.putInt("mode_button_pin", MODE_BUTTON_PIN);
      preferences.putInt("led_pin", LED_PIN);
      
      String response = "<html><head><title>Configuration Saved</title>"
                       "<style>body { font-family: Arial; margin: 20px; text-align: center; }"
                       "h1 { color: #4CAF50; }</style></head><body>"
                       "<h1>Configuration Saved!</h1>"
                       "<p>Relay 1 Active State: " + String(relayActiveStates[0] == HIGH ? "HIGH" : "LOW") + "</p>"
                       "<p>Relay 2 Active State: " + String(relayActiveStates[1] == HIGH ? "HIGH" : "LOW") + "</p>"
                       "<p>Mode Button Pin: GPIO " + String(MODE_BUTTON_PIN) + "</p>"
                       "<p>Status LED Pin: GPIO " + String(LED_PIN) + "</p>"
                       "<p><a href='/relay-config' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Configuration</a></p>"
                       "</body></html>";
      webServer.send(200, "text/html", response);
    }
  });

  webServer.on("/settings", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>Settings</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "}"
                 ".form-card:hover {"
                 "  transform: translateY(-5px);"
                 "  box-shadow: 0 5px 15px rgba(0,0,0,0.2);"
                 "}"
                 "@keyframes fadeIn {"
                 "  from { opacity: 0; transform: translateY(20px); }"
                 "  to { opacity: 1; transform: translateY(0); }"
                 "}"
                 ".form-group {"
                 "  margin-bottom: 20px;"
                 "  animation: slideIn 0.5s ease-in-out;"
                 "}"
                 "@keyframes slideIn {"
                 "  from { opacity: 0; transform: translateX(-20px); }"
                 "  to { opacity: 1; transform: translateX(0); }"
                 "}"
                 ".form-group label {"
                 "  display: block;"
                 "  margin-bottom: 5px;"
                 "  font-weight: 500;"
                 "}"
                 ".form-group input {"
                 "  width: 100%;"
                 "  padding: 8px;"
                 "  border: 1px solid #ddd;"
                 "  border-radius: 4px;"
                 "  transition: all 0.3s ease;"
                 "}"
                 ".form-group input:focus {"
                 "  border-color: var(--primary-color);"
                 "  box-shadow: 0 0 5px rgba(33, 150, 243, 0.3);"
                 "  transform: translateY(-2px);"
                 "}"
                 ".form-group select {"
                 "  width: 100%;"
                 "  padding: 8px;"
                 "  border: 1px solid #ddd;"
                 "  border-radius: 4px;"
                 "  transition: all 0.3s ease;"
                 "}"
                 ".form-group select:focus {"
                 "  border-color: var(--primary-color);"
                 "  box-shadow: 0 0 5px rgba(33, 150, 243, 0.3);"
                 "  transform: translateY(-2px);"
                 "}"
                 ".btn {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  border: none;"
                 "  padding: 10px 20px;"
                 "  border-radius: 4px;"
                 "  cursor: pointer;"
                 "  font-size: 16px;"
                 "}"
                 ".btn:hover {"
                 "  transform: scale(1.05);"
                 "  box-shadow: 0 4px 8px rgba(0,0,0,0.2);"
                 "}"
                 ".btn-success {"
                 "  background: var(--success-color);"
                 "}"
                 ".btn-danger {"
                 "  background: var(--danger-color);"
                 "}"
                 "</style>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>Settings</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='form-card'>"
                 "<h2>WiFi Settings</h2>"
                 "<form method='POST' action='/save-wifi'>"
                 "<div class='form-group'>"
                 "<label>WiFi SSID</label>"
                 "<input type='text' name='ssid' value='" + preferences.getString("wifi_ssid", "") + "' required>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>WiFi Password</label>"
                 "<input type='password' name='password' value='" + preferences.getString("wifi_password", "") + "' required>"
                 "</div>"
                 "<button type='submit' class='btn'>Save WiFi Settings</button>"
                 "</form>"
                 "</div>"
                 "<div class='form-card'>"
                 "<h2>MQTT Settings</h2>"
                 "<form method='POST' action='/save-mqtt'>"
                 "<div class='form-group'>"
                 "<label>MQTT Server</label>"
                 "<input type='text' name='mqtt_server' value='" + preferences.getString("mqtt_server", DEFAULT_MQTT_SERVER) + "' required>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>MQTT Port</label>"
                 "<input type='number' name='mqtt_port' value='" + String(preferences.getInt("mqtt_port", DEFAULT_MQTT_PORT)) + "' required>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>MQTT Username</label>"
                 "<input type='text' name='mqtt_username' value='" + preferences.getString("mqtt_username", "") + "'>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>MQTT Password</label>"
                 "<input type='password' name='mqtt_password' value='" + preferences.getString("mqtt_password", "") + "'>"
                 "</div>"
                 "<button type='submit' class='btn'>Save MQTT Settings</button>"
                 "</form>"
                 "</div>"
                 "<div class='form-card'>"
                 "<h2>System Settings</h2>"
                 "<form method='POST' action='/save-system'>"
                 "<div class='form-group'>"
                 "<label>Device Name</label>"
                 "<input type='text' name='device_name' value='SmartBoard' required>"
                 "</div>"
                 "<div class='form-group'>"
                 "<label>AP Mode Password</label>"
                 "<input type='password' name='ap_password' value='12345678' required>"
                 "</div>"
                 "<button type='submit' class='btn'>Save System Settings</button>"
                 "</form>"
                 "</div>"
                 "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  webServer.on("/save-wifi", HTTP_POST, []() {
    if (webServer.hasArg("ssid") && webServer.hasArg("password")) {
      preferences.putString("wifi_ssid", webServer.arg("ssid"));
      preferences.putString("wifi_password", webServer.arg("password"));
      
      String response = "<html><head><title>Settings Saved</title>"
                       "<style>body { font-family: Arial; margin: 20px; text-align: center; }"
                       "h1 { color: #4CAF50; }</style></head><body>"
                       "<h1>WiFi Settings Saved!</h1>"
                       "<p>Changes will take effect after restart.</p>"
                       "<p><a href='/settings' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Settings</a></p>"
                       "</body></html>";
      webServer.send(200, "text/html", response);
    }
  });

  webServer.on("/save-mqtt", HTTP_POST, []() {
    if (webServer.hasArg("mqtt_server") && webServer.hasArg("mqtt_port")) {
      preferences.putString("mqtt_server", webServer.arg("mqtt_server"));
      preferences.putInt("mqtt_port", webServer.arg("mqtt_port").toInt());
      preferences.putString("mqtt_username", webServer.arg("mqtt_username"));
      preferences.putString("mqtt_password", webServer.arg("mqtt_password"));
      
      String response = "<html><head><title>Settings Saved</title>"
                       "<style>body { font-family: Arial; margin: 20px; text-align: center; }"
                       "h1 { color: #4CAF50; }</style></head><body>"
                       "<h1>MQTT Settings Saved!</h1>"
                       "<p>Changes will take effect after restart.</p>"
                       "<p><a href='/settings' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Settings</a></p>"
                       "</body></html>";
      webServer.send(200, "text/html", response);
    }
  });

  webServer.on("/save-system", HTTP_POST, []() {
    if (webServer.hasArg("device_name") && webServer.hasArg("ap_password")) {
      preferences.putString("device_name", webServer.arg("device_name"));
      preferences.putString("ap_password", webServer.arg("ap_password"));
      
      String response = "<html><head><title>Settings Saved</title>"
                       "<style>body { font-family: Arial; margin: 20px; text-align: center; }"
                       "h1 { color: #4CAF50; }</style></head><body>"
                       "<h1>System Settings Saved!</h1>"
                       "<p>Changes will take effect after restart.</p>"
                       "<p><a href='/settings' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Back to Settings</a></p>"
                       "</body></html>";
      webServer.send(200, "text/html", response);
    }
  });

  webServer.on("/about", HTTP_GET, []() {
    String html = "<html><head>"
                 "<title>About SmartBoard</title>"
                 "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no'>"
                 "<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap' rel='stylesheet'>"
                 "<style>"
                 ":root {"
                 "  --primary-color: #2196F3;"
                 "  --success-color: #4CAF50;"
                 "  --danger-color: #f44336;"
                 "  --background-color: #f5f5f5;"
                 "  --card-color: #ffffff;"
                 "  --text-color: #333333;"
                 "  --shadow: 0 2px 4px rgba(0,0,0,0.1);"
                 "}"
                 "body {"
                 "  font-family: 'Roboto', sans-serif;"
                 "  margin: 0;"
                 "  padding: 0;"
                 "  background: var(--background-color);"
                 "  color: var(--text-color);"
                 "}"
                 ".container {"
                 "  max-width: 100%;"
                 "  margin: 0 auto;"
                 "  padding: 10px;"
                 "}"
                 ".header {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 15px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "  border-radius: 8px;"
                 "}"
                 ".nav {"
                 "  display: flex;"
                 "  flex-wrap: wrap;"
                 "  gap: 8px;"
                 "  margin-bottom: 15px;"
                 "}"
                 ".nav a {"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  padding: 10px 15px;"
                 "  text-decoration: none;"
                 "  border-radius: 4px;"
                 "  font-weight: 500;"
                 "}"
                 ".about-card {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  margin-bottom: 15px;"
                 "}"
                 ".feature-list {"
                 "  list-style-type: none;"
                 "  padding: 0;"
                 "}"
                 ".feature-list li {"
                 "  padding: 10px 0;"
                 "  border-bottom: 1px solid #eee;"
                 "}"
                 ".feature-list li:last-child {"
                 "  border-bottom: none;"
                 "}"
                 ".team-grid {"
                 "  display: grid;"
                 "  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));"
                 "  gap: 20px;"
                 "  margin-top: 20px;"
                 "}"
                 ".team-member {"
                 "  background: var(--card-color);"
                 "  padding: 20px;"
                 "  border-radius: 8px;"
                 "  box-shadow: var(--shadow);"
                 "  text-align: center;"
                 "}"
                 ".team-member h3 {"
                 "  margin: 10px 0;"
                 "  color: var(--primary-color);"
                 "  font-size: 1.2em;"
                 "}"
                 ".team-member p {"
                 "  color: #666;"
                 "  margin: 5px 0;"
                 "  font-size: 1.1em;"
                 "}"
                 ".role-badge {"
                 "  display: inline-block;"
                 "  padding: 5px 10px;"
                 "  background: var(--primary-color);"
                 "  color: white;"
                 "  border-radius: 15px;"
                 "  font-size: 0.8em;"
                 "  margin-top: 5px;"
                 "}"
                 "</style>"
                 "</head><body>"
                 "<div class='container'>"
                 "<div class='header'>"
                 "<h1>About SmartBoard</h1>"
                 "</div>"
                 "<div class='nav'>"
                 "<a href='/'>Status</a>"
                 "<a href='/settings'>Settings</a>"
                 "<a href='/manual-switches'>Manual Switches</a>"
                 "<a href='/relay-config'>Relay Config</a>"
                 "<a href='/pin-connections'>Pin Connections</a>"
                 "<a href='/about'>About</a>"
                 "</div>"
                 "<div class='about-card'>"
                 "<h2>Features</h2>"
                 "<ul class='feature-list'>"
                 "<li>2 Relay Control</li>"
                 "<li>Manual Switch Support</li>"
                 "<li>Web Interface</li>"
                 "<li>MQTT Integration</li>"
                 "<li>Bluetooth Control</li>"
                 "<li>Configurable Active States</li>"
                 "<li>Persistent Settings</li>"
                 "</ul>"
                 "</div>"
                 "<div class='about-card'>"
                 "<h2>Technical Details</h2>"
                 "<ul class='feature-list'>"
                 "<li>ESP32 Based</li>"
                 "<li>WiFi and Bluetooth Support</li>"
                 "<li>Web Server for Remote Control</li>"
                 "<li>MQTT for IoT Integration</li>"
                 "<li>Manual Switch Support with Configurable Active States</li>"
                 "</ul>"
                 "</div>"
                 "<div class='about-card'>"
                 "<h2>Development Team</h2>"
                 "<div class='team-grid'>"
                 "<div class='team-member'>"
                 "<h3>MOHIT</h3>"
                 "<p>Project Lead</p>"
                 "<span class='role-badge'>Team Leader</span>"
                 "</div>"
                 "<div class='team-member'>"
                 "<h3>ATUL</h3>"
                 "</div>"
                 "<div class='team-member'>"
                 "<h3>ABHAY</h3>"
                 "</div>"
                 "<div class='team-member'>"
                 "<h3>SAMIKSHA</h3>"
                 "</div>"
                 "<div class='team-member'>"
                 "<h3>NIKHIL</h3>"
                 "</div>"
                 "<div class='team-member'>"
                 "<h3>AKHILESH</h3>"
                 "</div>"
                 "</div>"
                 "</div>"
                 "</div></body></html>";
    webServer.send(200, "text/html", html);
  });

  webServer.begin();
}

void setupWiFiMQTTMode() {
  Serial.println("\n=== Setting up WiFi+MQTT Mode ===");
  
  // Disconnect from any existing connections
  if (WiFi.status() == WL_CONNECTED) {
    WiFi.disconnect();
  }
  if (mqttClient.connected()) {
    mqttClient.disconnect();
  }
  
  // Try to connect to WiFi
  isConnecting = true;
  if (!connectToWiFi()) {
    Serial.println("Failed to connect to WiFi - Falling back to AP mode");
    isConnecting = false;
    currentMode = AP_MODE;
    setupAPMode();
    return;
  }
  
  // Try to connect to MQTT
  if (!connectToMQTT()) {
    Serial.println("Failed to connect to MQTT - Staying in WiFi mode");
    isConnecting = false;
    return;
  }
  
  isConnecting = false;
  Serial.println("=== WiFi+MQTT Mode Setup Complete ===\n");
}

bool connectToWiFi() {
  String ssid = preferences.getString("wifi_ssid", "");
  String password = preferences.getString("wifi_password", "");
  
  if (ssid.length() == 0) {
    Serial.println("No WiFi credentials found");
    return false;
  }
  
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);
  
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), password.c_str());
  
  unsigned long startAttemptTime = millis();
  
  while (WiFi.status() != WL_CONNECTED && 
         millis() - startAttemptTime < WIFI_TIMEOUT) {
    // Check for mode button press during connection
    if (digitalRead(MODE_BUTTON_PIN) == LOW) {
      Serial.println("\nMode change requested during WiFi connection - Aborting connection");
      WiFi.disconnect();
      return false;
    }
    Serial.print(".");
        delay(500);
    }
    
    if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());
    wifiConnected = true;
    return true;
    } else {
    Serial.println("\nWiFi connection failed!");
    wifiConnected = false;
    return false;
  }
}

bool connectToMQTT() {
  if (!wifiConnected) {
    Serial.println("Cannot connect to MQTT - WiFi not connected");
    return false;
  }
  
  String mqttServer = preferences.getString("mqtt_server", DEFAULT_MQTT_SERVER);
  int mqttPort = preferences.getInt("mqtt_port", DEFAULT_MQTT_PORT);
  String mqttUsername = preferences.getString("mqtt_username", "");
  String mqttPassword = preferences.getString("mqtt_password", "");
  
  Serial.println("\n=== MQTT Connection Details ===");
  Serial.print("Server: "); Serial.println(mqttServer);
  Serial.print("Port: "); Serial.println(mqttPort);
  Serial.print("Username: "); Serial.println(mqttUsername.length() > 0 ? "Set" : "Not Set");
  Serial.print("Password: "); Serial.println(mqttPassword.length() > 0 ? "Set" : "Not Set");
  Serial.println("=============================\n");
  
  mqttClient.setServer(mqttServer.c_str(), mqttPort);
  mqttClient.setCallback(mqttCallback);
  
  while (!mqttClient.connected()) {
    // Check for mode button press during connection
    if (digitalRead(MODE_BUTTON_PIN) == LOW) {
      Serial.println("\nMode change requested during MQTT connection - Aborting connection");
      mqttClient.disconnect();
      return false;
    }
    
    bool connected = false;
    if (mqttUsername.length() > 0 && mqttPassword.length() > 0) {
      Serial.println("Attempting authenticated connection...");
      connected = mqttClient.connect("", mqttUsername.c_str(), mqttPassword.c_str());
            } else {
      Serial.println("Attempting unauthenticated connection...");
      connected = mqttClient.connect("");
    }
    
    if (connected) {
      Serial.println("MQTT connected successfully!");
      mqttClient.subscribe(MQTT_TOPIC);
      mqttConnected = true;
      return true;
    }
    
    Serial.print("MQTT connection failed. Error code: ");
    Serial.println(mqttClient.state());
    Serial.println("Retrying in 5 seconds...");
    delay(5000);
  }
  
  return false;
}

void setupBluetoothMode() {
  Serial.println("Setting up BLE...");
  
  try {
    // Create the BLE Device
    BLEDevice::init("SmartBoard");
    
    // Create the BLE Server
    pServer = BLEDevice::createServer();
    pServer->setCallbacks(new MyServerCallbacks());
    
    // Create the BLE Service
    BLEService *pService = pServer->createService(SERVICE_UUID);
    
    // Create a BLE Characteristic
    pCharacteristic = pService->createCharacteristic(
                        CHARACTERISTIC_UUID,
                        BLECharacteristic::PROPERTY_READ   |
                        BLECharacteristic::PROPERTY_WRITE  |
                        BLECharacteristic::PROPERTY_NOTIFY |
                        BLECharacteristic::PROPERTY_INDICATE
                      );
    
    // Create a BLE Descriptor
    pCharacteristic->addDescriptor(new BLE2902());
    
    // Set callbacks
    pCharacteristic->setCallbacks(new MyCallbacks());
    
    // Start the service
    pService->start();
    
    // Start advertising
    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(SERVICE_UUID);
    pAdvertising->setScanResponse(true);
    pAdvertising->setMinPreferred(0x06);  // functions that help with iPhone connections issue
    pAdvertising->setMaxPreferred(0x12);
    
    BLEDevice::startAdvertising();
    
    Serial.println("BLE setup complete");
    Serial.println("Device name: SmartBoard");
    Serial.println("Service UUID: " + String(SERVICE_UUID));
    Serial.println("Characteristic UUID: " + String(CHARACTERISTIC_UUID));
    Serial.println("Connect using BLE");
    btInitialized = true;
  } catch (...) {
    Serial.println("BLE setup failed!");
    btInitialized = false;
  }
}

void handleWebServer() {
  webServer.handleClient();
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  StaticJsonDocument<200> doc;
  DeserializationError error = deserializeJson(doc, message);
  
  if (!error) {
    bool stateChanged = false;
    for (int i = 0; i < NUM_RELAYS; i++) {
      if (doc.containsKey(("relay" + String(i)).c_str())) {
        relayStates[i] = doc[("relay" + String(i)).c_str()];
        digitalWrite(RELAY_PINS[i], relayStates[i] ? relayActiveStates[i] : !relayActiveStates[i]);
        stateChanged = true;
      }
    }
    
    if (stateChanged) {
      savePreferences();
      notifyBTStatus();
    }
  }
}

void reconnectMQTT() {
  while (!mqttClient.connected()) {
    if (mqttClient.connect("")) {
      mqttClient.subscribe(MQTT_TOPIC);
        } else {
      delay(5000);
    }
  }
}

void publishRelayStates() {
  if (!mqttClient.connected()) return;
  
  // Create JSON status
  String status = "{";
  for (int i = 0; i < NUM_RELAYS; i++) {
    status += "\"relay" + String(i) + "\":" + String(relayStates[i] ? "true" : "false");
    if (i < NUM_RELAYS - 1) status += ",";
  }
  status += "}";
  
  if (mqttClient.publish(MQTT_TOPIC, status.c_str())) {
    Serial.println("true");  // Simple true for terminal
  } else {
    Serial.println("false"); // Simple false for terminal
  }
}

void handleManualSwitches() {
  bool currentSwitch1State = digitalRead(MANUAL_SWITCH1_PIN);
  bool currentSwitch2State = digitalRead(MANUAL_SWITCH2_PIN);
  
  // For Switch 1
  if (currentSwitch1State != lastManualSwitch1State) {
    // Wait for debounce
    if (millis() - lastManualSwitch1Debounce > DEBOUNCE_DELAY) {
      // Only toggle on state change to active state
      if (currentSwitch1State == manualSwitch1ActiveState) {
        relayStates[manualSwitch1Relay] = !relayStates[manualSwitch1Relay];
        digitalWrite(RELAY_PINS[manualSwitch1Relay], relayStates[manualSwitch1Relay] ? relayActiveStates[manualSwitch1Relay] : !relayActiveStates[manualSwitch1Relay]);
        savePreferences();
        notifyBTStatus();
      }
      lastManualSwitch1State = currentSwitch1State;
      lastManualSwitch1Debounce = millis();
    }
  }
  
  // For Switch 2
  if (currentSwitch2State != lastManualSwitch2State) {
    // Wait for debounce
    if (millis() - lastManualSwitch2Debounce > DEBOUNCE_DELAY) {
      // Only toggle on state change to active state
      if (currentSwitch2State == manualSwitch2ActiveState) {
        relayStates[manualSwitch2Relay] = !relayStates[manualSwitch2Relay];
        digitalWrite(RELAY_PINS[manualSwitch2Relay], relayStates[manualSwitch2Relay] ? relayActiveStates[manualSwitch2Relay] : !relayActiveStates[manualSwitch2Relay]);
        savePreferences();
        notifyBTStatus();
      }
      lastManualSwitch2State = currentSwitch2State;
      lastManualSwitch2Debounce = millis();
    }
  }
}

void notifyBTStatus() {
  if (btInitialized && deviceConnected) {
    try {
      // Create a simple string status message
      String status = "R0:" + String(relayStates[0] ? "1" : "0") + ",R1:" + String(relayStates[1] ? "1" : "0");
      
      // Convert String to std::string for BLE
      std::string bleStatus = status.c_str();
      
      // Send status via BLE
      pCharacteristic->setValue(bleStatus);
      pCharacteristic->notify();
      
      // Print to serial for debugging
      Serial.println("Status sent via BLE: " + status);
      Serial.println("Current Relay States - R0: " + String(relayStates[0] ? "ON" : "OFF") + 
                    ", R1: " + String(relayStates[1] ? "ON" : "OFF"));
      
      // Add a small delay to ensure the notification is sent
      delay(50); // Increased delay for better reliability
    } catch (...) {
      Serial.println("Failed to send BLE notification");
    }
  }
}

void loop() {
  // Handle BLE connection state
  if (!deviceConnected && oldDeviceConnected) {
    delay(500); // give the bluetooth stack the chance to get things ready
    pServer->startAdvertising(); // restart advertising
    Serial.println("start advertising");
    oldDeviceConnected = deviceConnected;
  }
  
  // connecting
  if (deviceConnected && !oldDeviceConnected) {
    // do stuff here on connecting
    oldDeviceConnected = deviceConnected;
    // Send initial status when connected
    notifyBTStatus();
  }
  
  // Rest of the existing loop code...
  handleModeButton();
  updateLED();
  handleManualSwitches();
  
  // Handle BLE notifications if connected
  if (btInitialized && deviceConnected) {
    static unsigned long lastBTNotification = 0;
    if (millis() - lastBTNotification >= 1000) {
      notifyBTStatus();
      lastBTNotification = millis();
    }
  }
  
  switch (currentMode) {
    case AP_MODE:
      webServer.handleClient();
      break;
      
    case WIFI_MQTT_MODE:
      if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi disconnected - Attempting reconnect...");
        if (!connectToWiFi()) {
          Serial.println("WiFi reconnect failed - Switching to AP mode");
          currentMode = AP_MODE;
          setupAPMode();
          break;
        }
      }
      
      if (!mqttClient.connected()) {
        static unsigned long lastMqttReconnectAttempt = 0;
        unsigned long currentTime = millis();
        
        if (currentTime - lastMqttReconnectAttempt > MQTT_RECONNECT_DELAY) {
          lastMqttReconnectAttempt = currentTime;
          Serial.println("MQTT disconnected - Attempting reconnect...");
          if (!connectToMQTT()) {
            Serial.println("MQTT reconnect failed - Will retry later");
          }
        }
      }
      
      mqttClient.loop();
      
      // Publish status periodically
      static unsigned long lastMqttPublish = 0;
      if (millis() - lastMqttPublish >= MQTT_PUBLISH_INTERVAL) {
        publishRelayStates();
        lastMqttPublish = millis();
      }
      break;
  }
}
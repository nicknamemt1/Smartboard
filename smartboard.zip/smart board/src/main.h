#ifndef MAIN_H
#define MAIN_H

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <PubSubClient.h>
#include <Preferences.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <ArduinoJson.h>

// Function Declarations
void savePreferences();
void notifyBTStatus();
void setupPins();
void loadPreferences();
void handleModeButton();
void updateLED();
void setupAPMode();
void setupWiFiMQTTMode();
void setupBluetoothMode();
void handleWebServer();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void reconnectMQTT();
void publishRelayStates();
void handleManualSwitches();
void printModeStatus();
bool connectToWiFi();
bool connectToMQTT();

#endif // MAIN_H 
#ifndef CONFIG_H
#define CONFIG_H

// GPIO Pin Configuration
#define OUTPUT_1    12
#define OUTPUT_2    13
#define OUTPUT_3    14
#define OUTPUT_4    15

// ZMPT101B Configuration
#define VOLTAGE_SENSOR_PIN   34
#define SAMPLES_PER_READ     100
#define VOLTAGE_RANGE_MIN    0
#define VOLTAGE_RANGE_MAX    300

// WiFi Configuration
#define WIFI_RETRY_DELAY    5000
#define MAX_WIFI_RETRIES    5

// MQTT Configuration
#define MQTT_PORT           1883
#define MQTT_RETRY_DELAY    5000
#define MAX_MQTT_RETRIES    3

// MQTT Topics
#define MQTT_TOPIC_CONTROL  "device/outputs/control"
#define MQTT_TOPIC_STATUS   "device/outputs/status"
#define MQTT_TOPIC_VOLTAGE  "device/sensor/voltage"

// Bluetooth Configuration
#define BT_DEVICE_NAME      "ESP32_CONTROL"

// General Configuration
#define SERIAL_BAUD_RATE    115200
#define UPDATE_INTERVAL     1000  // 1 second

#endif // CONFIG_H